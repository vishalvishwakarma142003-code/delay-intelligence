import os
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, GridSearchCV, RandomizedSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import (
    confusion_matrix, accuracy_score, precision_score,
    recall_score, f1_score
)

from src.shipment_prep import FEATURES, NOISE_COLUMNS

os.makedirs("outputs", exist_ok=True)

df = pd.read_csv("data/modelling_table.csv")
X = df[FEATURES]
y = df["is_delayed"]

X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp
)

def score_row(name, actual, predicted):
    tn, fp, fn, tp = confusion_matrix(
        actual, predicted, labels=[0, 1]
    ).ravel()
    return {
        "model": name, "TN": tn, "FP": fp, "FN": fn, "TP": tp,
        "accuracy": accuracy_score(actual, predicted),
        "precision": precision_score(actual, predicted, zero_division=0),
        "recall": recall_score(actual, predicted, zero_division=0),
        "f1": f1_score(actual, predicted, zero_division=0)
    }

# Baseline and three classifiers
model_rows = [score_row(
    "blind_all_on_time", y_val, np.zeros(len(y_val), dtype=int)
)]

logistic = Pipeline([
    ("scaler", StandardScaler()),
    ("model", LogisticRegression(max_iter=2000, random_state=42))
])
logistic.fit(X_train, y_train)
model_rows.append(score_row(
    "logistic_regression", y_val, logistic.predict(X_val)
))

tree_results = []
for depth in [2, 3, 4, 5, 6, 8, 10]:
    tree = DecisionTreeClassifier(
        criterion="gini", max_depth=depth, random_state=42
    )
    tree.fit(X_train, y_train)
    pred = tree.predict(X_val)
    tree_results.append((f1_score(y_val, pred), depth, tree, pred))

tree_results.sort(key=lambda x: (-x[0], x[1]))
best_tree_f1, best_tree_depth, best_tree, best_tree_pred = tree_results[0]
model_rows.append(score_row(
    f"decision_tree_depth_{best_tree_depth}", y_val, best_tree_pred
))

forest_all = RandomForestClassifier(n_estimators=100, random_state=42)
forest_all.fit(X_train, y_train)
model_rows.append(score_row(
    "random_forest_default", y_val, forest_all.predict(X_val)
))

pd.DataFrame(model_rows).round(4).to_csv(
    "outputs/part_c_models.csv", index=False
)

# Feature scores and importance
selector_all = SelectKBest(f_classif, k="all")
selector_all.fit(X_train, y_train)
f_scores = selector_all.scores_

importance = forest_all.feature_importances_
score_df = pd.DataFrame({
    "feature": FEATURES,
    "f_score": f_scores,
    "rf_importance": importance,
    "is_noise": [f in NOISE_COLUMNS for f in FEATURES]
})
score_df["f_rank"] = score_df["f_score"].rank(
    ascending=False, method="min"
).astype(int)
score_df = score_df[
    ["feature", "f_score", "f_rank", "rf_importance", "is_noise"]
].sort_values(["f_rank", "feature"])
score_df.round(4).to_csv(
    "outputs/part_c_feature_scores.csv", index=False
)

# Compare selected feature counts
selectk_rows = []
for k in [5, 7, 10, 12, 17]:
    pipe = Pipeline([
        ("selector", SelectKBest(f_classif, k=k)),
        ("model", RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    pipe.fit(X_train, y_train)
    selectk_rows.append({
        "k": k,
        "val_f1": f1_score(y_val, pipe.predict(X_val))
    })

pd.DataFrame(selectk_rows).round(4).to_csv(
    "outputs/part_c_selectk.csv", index=False
)

# Fit selector on training data only
selector = SelectKBest(f_classif, k=7)
X_train_7 = selector.fit_transform(X_train, y_train)
X_val_7 = selector.transform(X_val)

grid = {
    "n_estimators": [50, 100, 150],
    "max_depth": [4, 6, 8],
    "min_samples_leaf": [1, 5, 10]
}

grid_search = GridSearchCV(
    RandomForestClassifier(random_state=42),
    grid, cv=5
)
grid_search.fit(X_train_7, y_train)

random_search = RandomizedSearchCV(
    RandomForestClassifier(random_state=42),
    grid, n_iter=9, cv=5, random_state=42
)
random_search.fit(X_train_7, y_train)

default_forest = RandomForestClassifier(
    n_estimators=100, random_state=42,
    max_depth=None, min_samples_leaf=1
)
default_forest.fit(X_train_7, y_train)

candidate_models = [
    ("grid_search", grid_search.best_estimator_, grid_search.best_params_,
     27, 5, 135, grid_search.best_score_),
    ("randomized_search", random_search.best_estimator_, random_search.best_params_,
     9, 5, 45, random_search.best_score_),
    ("default_forest_same_7_features", default_forest,
     {"n_estimators": 100, "max_depth": None, "min_samples_leaf": 1},
     1, 0, 1, np.nan)
]

tuning_rows = []
for name, model, params, candidates, folds, fits, cv_acc in candidate_models:
    pred = model.predict(X_val_7)
    tuning_rows.append({
        "search": name,
        "candidates": candidates,
        "cv_folds": folds,
        "total_fits": fits,
        "best_params": str(params),
        "best_cv_accuracy": cv_acc,
        "val_f1": f1_score(y_val, pred)
    })

tuning_df = pd.DataFrame(tuning_rows)
tuning_df.round(4).to_csv("outputs/part_c_tuning.csv", index=False)

# Select winner: highest validation F1; ties use the required priority
priority = {
    "default_forest_same_7_features": 0,
    "grid_search": 1,
    "randomized_search": 2
}
winner_row = sorted(
    tuning_rows,
    key=lambda r: (-r["val_f1"], priority[r["search"]])
)[0]
winner_name = winner_row["search"]
winner_params = candidate_models[
    [c[0] for c in candidate_models].index(winner_name)
][2]

# Rebuild the final pipeline and fit training rows
final_model = Pipeline([
    ("selector", SelectKBest(f_classif, k=7)),
    ("model", RandomForestClassifier(
        random_state=42,
        n_estimators=int(winner_params["n_estimators"]),
        max_depth=winner_params["max_depth"],
        min_samples_leaf=int(winner_params["min_samples_leaf"])
    ))
])
final_model.fit(X_train, y_train)

# Choose highest threshold whose validation recall is at least 0.80
val_prob = final_model.predict_proba(X_val)[:, 1]
thresholds = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
threshold_rows = []

for threshold in thresholds:
    pred = (val_prob >= threshold).astype(int)
    threshold_rows.append({
        "threshold": threshold,
        **{k: v for k, v in score_row("tmp", y_val, pred).items()
           if k != "model"}
    })

threshold_df = pd.DataFrame(threshold_rows)
threshold_df.round(4).to_csv(
    "outputs/part_c_thresholds.csv", index=False
)

valid_thresholds = threshold_df[threshold_df["recall"] >= 0.80]
chosen_threshold = (
    float(valid_thresholds["threshold"].max())
    if len(valid_thresholds) else 0.1
)

# Evaluate test exactly once at the chosen threshold
test_prob = final_model.predict_proba(X_test)[:, 1]
test_pred = (test_prob >= chosen_threshold).astype(int)
test_row = score_row("final_model", y_test, test_pred)
test_row["threshold"] = chosen_threshold
pd.DataFrame([{k: v for k, v in test_row.items() if k != "model"}]).round(4).to_csv(
    "outputs/part_c_final_test.csv", index=False
)

model_params = final_model.named_steps["model"].get_params()
pd.DataFrame([{
    "selector_k": 7,
    "n_estimators": model_params["n_estimators"],
    "max_depth": "unlimited" if model_params["max_depth"] is None else model_params["max_depth"],
    "min_samples_leaf": model_params["min_samples_leaf"],
    "threshold": chosen_threshold,
    "chosen_from": winner_name
}]).to_csv("outputs/part_c_final_config.csv", index=False)

print("Part C completed.")
print("Selected configuration:", winner_name)
print("Alert threshold:", chosen_threshold)
print(pd.read_csv("outputs/part_c_final_test.csv"))
