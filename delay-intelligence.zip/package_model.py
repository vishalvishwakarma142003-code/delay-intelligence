import os
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

from src.shipment_prep import FEATURES, clean_shipments, build_features

os.makedirs("models", exist_ok=True)
os.makedirs("outputs", exist_ok=True)

raw = pd.read_csv("data/raw_shipments.csv")
hubs = pd.read_csv("data/hubs.csv")
clean, medians = clean_shipments(raw)
df = build_features(clean, hubs)
df["is_delayed"] = (
    df["delivery_hours"] > df["promised_hours"]
).astype(int)

X = df[FEATURES]
y = df["is_delayed"]

X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp
)

config = pd.read_csv("outputs/part_c_final_config.csv").iloc[0]
max_depth = config["max_depth"]
if str(max_depth).lower() in ["unlimited", "none", "nan"]:
    max_depth = None
else:
    max_depth = int(max_depth)

model = Pipeline([
    ("selector", SelectKBest(f_classif, k=int(config["selector_k"]))),
    ("model", RandomForestClassifier(
        random_state=42,
        n_estimators=int(config["n_estimators"]),
        max_depth=max_depth,
        min_samples_leaf=int(config["min_samples_leaf"])
    ))
])
model.fit(X_train, y_train)

joblib.dump(model, "models/delay_model.pkl")

pd.DataFrame({"threshold": [float(config["threshold"])]}).to_csv(
    "models/delay_threshold.csv", index=False
)
pd.DataFrame({"feature": FEATURES}).to_csv(
    "models/feature_order.csv", index=False
)
pd.DataFrame([
    {"column": col, "median": value}
    for col, value in medians.items()
]).to_csv("models/impute_values.csv", index=False)

# Reload test: probabilities must be unchanged
reloaded = joblib.load("models/delay_model.pkl")
original_prob = model.predict_proba(X_test)[:, 1]
reloaded_prob = reloaded.predict_proba(X_test)[:, 1]

check_rows = [
    {"metric": "test_rows_scored", "value": len(X_test)},
    {"metric": "reload_max_abs_probability_diff",
     "value": np.max(np.abs(original_prob - reloaded_prob))},
    {"metric": "threshold", "value": float(config["threshold"])}
]
pd.DataFrame(check_rows).round(10).to_csv(
    "outputs/part_d_reload_check.csv", index=False
)

print("Model packaged successfully.")
print(pd.read_csv("outputs/part_d_reload_check.csv"))
