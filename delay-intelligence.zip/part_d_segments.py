import os
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances

os.makedirs("outputs", exist_ok=True)

df = pd.read_csv("data/modelling_table.csv")

# Create a profile for each hub and keep hub order fixed
profile = df.groupby("hub_id", sort=True).agg(
    shipments=("shipment_id", "count"),
    mean_delivery_hours=("delivery_hours", "mean"),
    delay_rate=("is_delayed", "mean"),
    mean_distance_km=("distance_km", "mean"),
    mean_n_stops=("n_stops", "mean")
).reset_index().sort_values("hub_id").reset_index(drop=True)

profile.round(4).to_csv("outputs/hub_profile.csv", index=False)

profile_cols = [
    "mean_delivery_hours", "delay_rate",
    "mean_distance_km", "mean_n_stops"
]
scaled = StandardScaler().fit_transform(profile[profile_cols])

# Separation ratio for K = 2, 3, 4, 5
distance_matrix = pairwise_distances(scaled)
separation_rows = []

for k in [2, 3, 4, 5]:
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(scaled)

    within = []
    across = []

    for i in range(len(labels)):
        for j in range(i + 1, len(labels)):
            if labels[i] == labels[j]:
                within.append(distance_matrix[i, j])
            else:
                across.append(distance_matrix[i, j])

    sizes = sorted(
        pd.Series(labels).value_counts().tolist(), reverse=True
    )

    separation_rows.append({
        "K": k,
        "across_over_within": np.mean(across) / np.mean(within),
        "cluster_sizes": "-".join(map(str, sizes))
    })

pd.DataFrame(separation_rows).round(4).to_csv(
    "outputs/part_d_separation.csv", index=False
)

# Business requires exactly three segments
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
profile["cluster"] = kmeans.fit_predict(scaled)

cluster_rates = profile.groupby("cluster")["delay_rate"].mean().sort_values()
names = {
    cluster_rates.index[0]: "Standard",
    cluster_rates.index[1]: "Watch",
    cluster_rates.index[2]: "Escalate"
}
profile["segment"] = profile["cluster"].map(names)

hub_info = df[["hub_id", "hub_city", "hub_tier"]].drop_duplicates("hub_id")
segments = profile[["hub_id", "segment"]].merge(
    hub_info, on="hub_id", how="left", validate="one_to_one"
)
segments = segments[["hub_id", "segment", "hub_city", "hub_tier"]]
segments.sort_values("hub_id").to_csv("outputs/hub_segments.csv", index=False)

# Segment profiles are means of hub-level profiles
segment_profile = profile.groupby("segment").agg(
    hubs=("hub_id", "count"),
    mean_delivery_hours=("mean_delivery_hours", "mean"),
    delay_rate=("delay_rate", "mean"),
    mean_distance_km=("mean_distance_km", "mean"),
    mean_n_stops=("mean_n_stops", "mean")
).reset_index()

segment_order = {"Standard": 0, "Watch": 1, "Escalate": 2}
segment_profile["_order"] = segment_profile["segment"].map(segment_order)
segment_profile = segment_profile.sort_values("_order").drop(columns="_order")
segment_profile.round(4).to_csv("outputs/segment_profile.csv", index=False)

# Compare actual segment with the segment implied by the hub tier
expected_segment = {1: "Standard", 2: "Watch", 3: "Escalate"}
mismatch = segments[
    segments.apply(
        lambda row: row["segment"] != expected_segment[row["hub_tier"]],
        axis=1
    )
]
mismatch.to_csv("outputs/tier_vs_segment_mismatch.csv", index=False)

print("Part D segmentation completed.")
print(segment_profile.round(4))
print("Tier/segment mismatches:", len(mismatch))
