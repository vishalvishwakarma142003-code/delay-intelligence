import os
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split, KFold, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from src.shipment_prep import FEATURES

os.makedirs("outputs", exist_ok=True)

df = pd.read_csv("data/modelling_table.csv")
X = df[FEATURES]
y = df["delivery_hours"]

X_train, X_temp, y_train, y_temp = train_test_split(
    X, y, test_size=0.3, random_state=42
)
X_val, X_test, y_val, y_test = train_test_split(
    X_temp, y_temp, test_size=0.5, random_state=42
)

# Scale only for the scaler check and linear regression pipeline
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
X_test_scaled = scaler.transform(X_test)

pd.DataFrame([
    {"metric": "train_rows", "value": len(X_train)},
    {"metric": "val_rows", "value": len(X_val)},
    {"metric": "test_rows", "value": len(X_test)},
    {"metric": "train_scaled_max_abs_mean",
     "value": np.abs(X_train_scaled.mean(axis=0)).max()},
    {"metric": "test_scaled_max_abs_mean",
     "value": np.abs(X_test_scaled.mean(axis=0)).max()}
]).round(4).to_csv("outputs/part_b_checks.csv", index=False)

def metrics_row(name, split, actual, predicted):
    mse = mean_squared_error(actual, predicted)
    return {
        "model": name,
        "split": split,
        "MAE": mean_absolute_error(actual, predicted),
        "MSE": mse,
        "RMSE": np.sqrt(mse),
        "R2": r2_score(actual, predicted)
    }

# Mean baseline
baseline_pred = np.repeat(y_train.mean(), len(y_val))
rows = [metrics_row("mean_baseline", "val", y_val, baseline_pred)]

# Decision-tree depth experiment
depth_rows = []
depth_options = [1, 2, 3, 4, 6, 8, 12, None]

for depth in depth_options:
    tree = DecisionTreeRegressor(max_depth=depth, random_state=42)
    tree.fit(X_train, y_train)

    train_pred = tree.predict(X_train)
    val_pred = tree.predict(X_val)

    depth_rows.append({
        "max_depth": "unlimited" if depth is None else depth,
        "train_rmse": np.sqrt(mean_squared_error(y_train, train_pred)),
        "val_rmse": np.sqrt(mean_squared_error(y_val, val_pred))
    })

depth_df = pd.DataFrame(depth_rows)
depth_df = depth_df.round(4)
depth_df.to_csv("outputs/part_b_tree_depth.csv", index=False)

best_depth_value = depth_df.loc[depth_df["val_rmse"].idxmin(), "max_depth"]
best_depth = None if best_depth_value == "unlimited" else int(best_depth_value)

# Four candidate models
models = {
    "linear_regression": Pipeline([
        ("scaler", StandardScaler()),
        ("model", LinearRegression())
    ]),
    "decision_tree": DecisionTreeRegressor(
        max_depth=best_depth, random_state=42
    ),
    "random_forest": RandomForestRegressor(
        n_estimators=100, random_state=42
    ),
    "gradient_boosting": GradientBoostingRegressor(
        n_estimators=100, learning_rate=0.1, random_state=42
    )
}

fitted_models = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    fitted_models[name] = model
    rows.append(metrics_row(name, "val", y_val, model.predict(X_val)))

# Learning-rate experiment
lr_rows = []
for lr in [0.01, 0.1, 1.0]:
    model = GradientBoostingRegressor(
        n_estimators=100, learning_rate=lr, random_state=42
    )
    model.fit(X_train, y_train)
    pred = model.predict(X_val)
    lr_rows.append({
        "learning_rate": lr,
        "val_rmse": np.sqrt(mean_squared_error(y_val, pred)),
        "val_r2": r2_score(y_val, pred)
    })

pd.DataFrame(lr_rows).round(4).to_csv(
    "outputs/part_b_gb_learning_rate.csv", index=False
)

# Cross-validation on training + validation rows
X_trainval = pd.concat([X_train, X_val])
y_trainval = pd.concat([y_train, y_val])

ranked = sorted(
    fitted_models.items(),
    key=lambda item: mean_squared_error(
        y_val, item[1].predict(X_val)
    )
)
cv = KFold(n_splits=5, shuffle=True, random_state=42)
cv_rows = []

for name, model in ranked[:2]:
    scores = cross_val_score(
        model, X_trainval, y_trainval, cv=cv
    )
    cv_rows.append({
        "model": name,
        "mean_r2": scores.mean(),
        "std_r2": scores.std()
    })

pd.DataFrame(cv_rows).round(4).to_csv(
    "outputs/part_b_cv.csv", index=False
)

# Select the lowest validation-RMSE model, then evaluate test once
best_name = min(
    fitted_models,
    key=lambda name: mean_squared_error(
        y_val, fitted_models[name].predict(X_val)
    )
)
best_model = fitted_models[best_name]
rows.append(metrics_row(
    best_name, "test", y_test, best_model.predict(X_test)
))

pd.DataFrame(rows).round(4).to_csv(
    "outputs/part_b_metrics.csv", index=False
)

print("Part B completed.")
print("Best validation model:", best_name)
print(pd.read_csv("outputs/part_b_metrics.csv"))
