import os
import numpy as np
import pandas as pd
from src.shipment_prep import (
    FEATURES, PROMISED_HOURS, clean_shipments, build_features
)

os.makedirs("outputs", exist_ok=True)
os.makedirs("data", exist_ok=True)

raw = pd.read_csv("data/raw_shipments.csv")
hubs = pd.read_csv("data/hubs.csv")

raw_dedup = raw.drop_duplicates().copy()
raw_count = len(raw)
duplicate_count = raw_count - len(raw_dedup)

service_before = raw_dedup["service_type"].nunique()
missing_distance = raw_dedup["distance_km"].isna().sum()
missing_weight = raw_dedup["parcel_weight_kg"].isna().sum()
missing_value = raw_dedup["declared_value"].isna().sum()
missing_payment = raw_dedup["payment_mode"].isna().sum()
sentinel_count = (raw_dedup["parcel_weight_kg"] > 100).sum()

clean, medians = clean_shipments(raw)
model_table = build_features(clean, hubs)

service_after = clean["service_type"].nunique()
model_table["is_delayed"] = (
    model_table["delivery_hours"] > model_table["promised_hours"]
).astype(int)

model_table.to_csv("data/modelling_table.csv", index=False)

# Part A checks
hours = model_table["delivery_hours"]
q1 = hours.quantile(0.25)
q3 = hours.quantile(0.75)
iqr = q3 - q1
lower_bound = q1 - 1.5 * iqr
upper_bound = q3 + 1.5 * iqr

log_values = np.log(model_table["declared_value_inr"])

checks = {
    "raw_rows": raw_count,
    "duplicate_rows_removed": duplicate_count,
    "rows_after_dedup": len(raw_dedup),
    "missing_distance_km_before": missing_distance,
    "missing_parcel_weight_before": missing_weight,
    "missing_declared_value_before": missing_value,
    "missing_payment_mode_before": missing_payment,
    "sentinel_weight_rows": sentinel_count,
    "service_type_spellings_before": service_before,
    "service_type_spellings_after": service_after,
    "median_distance_km": medians["distance_km"],
    "median_parcel_weight_kg": medians["parcel_weight_kg"],
    "median_declared_value_inr": medians["declared_value_inr"],
    "rows_after_hub_merge": len(model_table),
    "nulls_in_features_and_target": int(
        model_table[FEATURES + ["delivery_hours", "is_delayed"]]
        .isna().sum().sum()
    ),
    "delayed_count": int(model_table["is_delayed"].sum()),
    "delay_rate": model_table["is_delayed"].mean(),
    "hours_q1": q1,
    "hours_q3": q3,
    "hours_lower_bound": lower_bound,
    "hours_upper_bound": upper_bound,
    "hours_outlier_count": int(
        ((hours < lower_bound) | (hours > upper_bound)).sum()
    ),
    "declared_value_mean_inr": model_table["declared_value_inr"].mean(),
    "declared_value_median_inr": model_table["declared_value_inr"].median(),
    "log_declared_value_mean": log_values.mean(),
    "log_declared_value_median": log_values.median()
}

pd.DataFrame([
    {"metric": k, "value": round(float(v), 4) if isinstance(v, (float, np.floating)) else v}
    for k, v in checks.items()
]).to_csv("outputs/part_a_checks.csv", index=False)

# Delay by service type
group_tables = []

for dimension, col in [
    ("service_type", "service_type"),
    ("hub_tier", "hub_tier")
]:
    grouped = model_table.groupby(col, dropna=False).agg(
        shipments=("is_delayed", "size"),
        delayed=("is_delayed", "sum"),
        delay_rate=("is_delayed", "mean"),
        mean_hours=("delivery_hours", "mean")
    ).reset_index()

    grouped = grouped.rename(columns={col: "group"})
    grouped["dimension"] = dimension
    group_tables.append(
        grouped[["dimension", "group", "shipments", "delayed", "delay_rate", "mean_hours"]]
    )

model_table["distance_band"] = pd.cut(
    model_table["distance_km"],
    bins=[0, 200, 400, 600, 2000],
    labels=["0-200", "201-400", "401-600", "601+"],
    right=True,
    include_lowest=True
)

grouped = model_table.groupby(
    "distance_band", observed=False
).agg(
    shipments=("is_delayed", "size"),
    delayed=("is_delayed", "sum"),
    delay_rate=("is_delayed", "mean"),
    mean_hours=("delivery_hours", "mean")
).reset_index().rename(columns={"distance_band": "group"})

grouped["dimension"] = "distance_band"
group_tables.append(
    grouped[["dimension", "group", "shipments", "delayed", "delay_rate", "mean_hours"]]
)

pd.concat(group_tables, ignore_index=True).round(4).to_csv(
    "outputs/part_a_delay_by_group.csv", index=False
)

# Numeric correlation matrix
numeric = model_table.select_dtypes(include="number")
corr = numeric.corr().round(4)
corr.to_csv("outputs/part_a_correlations.csv", index_label="column")

print("Part A completed.")
print("Rows:", len(model_table))
print("Delayed parcels:", int(model_table["is_delayed"].sum()))
print("Delay rate:", round(model_table["is_delayed"].mean(), 4))
print("Medians:", medians)
